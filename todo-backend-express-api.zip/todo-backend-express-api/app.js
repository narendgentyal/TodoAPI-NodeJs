// import all dependencies
const express = require('express');
const app = express();
const bodyParser = require('body-parser');
const cors = require('cors');
// create a passport instance
var passport = require('passport');
// associating passport object with passport-jwt strategy
var myPassportService
    = require('./db/passport')(passport);
//importing routes from Router File
const routeUsers = require('./routes/user.routes');
// importing custom routes
const todoRoutes = require('./routes/todo.routes');

// enable cors for all routes
app.use(cors());
// registering middleware for request-response pipeline
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true }));
// enabling passport authentication for routes
app.use(passport.initialize());
app.use(passport.session());


// Default Route
app.use('/api/users', routeUsers);
app.use('/api/todos', todoRoutes);

const PORT = process.env.PORT || 4000;
// start the server
app.listen(PORT, function () {
    console.log("Server is running on Port: " + PORT);
});

module.exports = app;