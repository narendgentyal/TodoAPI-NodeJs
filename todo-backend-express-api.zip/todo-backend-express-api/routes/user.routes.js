// for routes
const express = require('express');
const router = express.Router();
const jwt = require('jsonwebtoken');
// for db connection
const mongoose = require('mongoose');
//import from user.model.js Module
const User = require('../models/user.model');
// passport authentication using jwt token
const passport = require('passport');
// for connection string
const config = require('../db/config');

// STEP3 - CONNECT MONGODB DATABASE
//Connecting Mongodb server
mongoose.connect(config.DB,
    { useNewUrlParser: true, useUnifiedTopology: true });

let db = mongoose.connection;
//when connection open
db.once('open', function () {
    console.log('Connection Open with MongoDB Server ..!');
});
//check for db error
db.on('error', function (err) {
    console.log("Error : " + err.stack);
});

// POST /api/users/register
router.post('/register', (req, res) => {
    let newUser = new User({
        name: req.body.name,
        email: req.body.email,
        username: req.body.username,
        password: req.body.password
    });
    console.log(newUser);
    // calling function from user.model.js file
    User.addUser(newUser, (err, user) => {
        if (err) {
            res.json({
                success: false,
                msg: 'Failed to Register'
            });
        }
        else {
            res.json({
                success: true,
                msg: 'User is Registered'
            });
        }
    });
});

// POST /api/users/login
router.post('/login', (req, res) => {
    const email = req.body.email;
    const password = req.body.password;

    console.log(email, " ", password);

    // calling from user.model.js file
    User.getUsersByUserName(email, (err, user) => {
        if (err) throw err;
            if (!user)
                return res.json({
                    success: false,
                    msg: 'User not found'
                })
        // calling from user.model.js file
        User.comparePassword(password, user.password,
            (err, isMatch) => {
                if (err) throw err;
                if (isMatch) {
                    // idle expire time bydefault is for 10 mins
                    // expiresIn: 604800
                    const token
                        = jwt.sign(user.toObject(),
                            config.secret, { expiresIn: 604800 })

                    res.json({
                        success: true,
                        token: 'JWT ' + token,
                        user: {
                            id: user._id,
                            name: user.name,
                            username: user.username,
                            email: user.email
                        }
                    })
                }
                else {
                    return res.json({
                        success: false,
                        msg: 'Wrong Password'
                    })
                }
            })
    })
}) // end of login post


// GET /api/users/profile
router.get('/profile',
    passport.authenticate('jwt', { session: false }),
    (req, res) => {
        res.json({ user: req.user });
    })

module.exports = router;