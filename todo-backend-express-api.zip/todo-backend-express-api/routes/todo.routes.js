//import modules
const express = require('express');
const mongoose = require('mongoose');
const config = require('../db/config');
const todoRoutes = express.Router();
// import custom Todo model
let Todo = require('../models/todo.model');
// passport authentication using jwt token
const passport = require('passport');

// connecting to mongodb 
mongoose.connect(config.DB,
    { useNewUrlParser: true, useUnifiedTopology: true });

let db = mongoose.connection;
//when connection open
db.once('open', function () {
    console.log("MongoDB database connection established successfully");
});
//check for db error
db.on('error', function (err) {
    console.log('Error: Cannot connect to database - '
        + err.stack);
})

// Defining Routes
// list of todos
todoRoutes.route('/').get(passport.authenticate('jwt', { session: false }),
    function (req, res) {
        Todo.find(function (err, todos) {
            if (err) {
                res.status(500).json(err.stack);
            } else {
                res.status(200).json(todos);
            }
        });
    });

// list todo by id
todoRoutes.route('/:id').get(passport.authenticate('jwt', { session: false }),
    function (req, res) {
        let id = req.params.id;
        Todo.findById(id, { __v: 0 }, function (err, todo) {
            if (err) {
                res.status(500).json(err.stack);
            }
            else { res.status(200).json(todo); }
        });
    });

// Add Todo
todoRoutes.route('/').post(passport.authenticate('jwt', { session: false }),
    function (req, res) {
        let todo = new Todo(req.body);
        todo.save(function (err) {
            if (err) {
                res.status(500).json({
                    "message": 'Error: Adding new todo failed: '
                        + err.stack
                });
            } else {
                res.status(200).json({ 'message': 'Todo is Added Successfully!' });
            }
        });
    });


// update todo by id 
todoRoutes.route('/:id').put(passport.authenticate('jwt', { session: false }),
    function (req, res) {
        Todo.findById(req.params.id, function (err, todo) {
            if (err) {
                return res.status(500).json(err.stack);
            }
            if (!todo)
                res.status(404).json
                    ({ "message": "Error: Todo is not found" });
            else {
                todo.todoDescription = req.body.todoDescription;
                todo.todoResponsible = req.body.todoResponsible;
                todo.todoStatus = req.body.todoStatus;

                todo.save(function (err) {
                    if (err) {
                        res.status(500).json({
                            "message": "Error: Update to Todo is not possible - "
                                + err.stack
                        });
                        return;
                    }

                    res.status(200)
                        .json({ 'message': 'Todo is Updated Successfully!' });
                });
            }
        });
    });

// delete todo by id
todoRoutes.route('/:id')
    .delete(passport.authenticate('jwt', { session: false }),
        function (req, res) {
            Todo.deleteOne({ _id: req.params.id },
                function (err, todo) {
                    if (err) {
                        res.status(500).json(err.stack);
                        return;
                    }
                    res.status(200).json({
                        message:
                            'Todo is Successfully Deleted!'
                    });
                });
        });
// export todoRoutes
module.exports = todoRoutes;