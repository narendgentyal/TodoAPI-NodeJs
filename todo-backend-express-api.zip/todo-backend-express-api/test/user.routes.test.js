// FOLLOW BELOW STEPS TO EXECUTE THIS FILE
/*
INSTALL THE DEPENDENCIES
npm install --save-dev supertest mocha chai

RUN TEST FILE
mocha user.routes.test.js


*/
var request = require('supertest');
var app = require('../app');
// bdd approach
var assert = require('chai').assert;

// TESTING /api/users/login API WITH supertest 
describe('POST /api/users/login', function () {
    it('login verification with json data',
        function (done) {
            request(app)
                .post('/api/users/register')
                .send({
                    "name": "Mahendra",
                    "email": "mahendra@gmail.com",
                    "username": "mahendra",
                    "password": "123456"
                })
                .set('Accept', 'application/json')
                .expect('Content-Type', /json/)
                .expect(200)
                .end(function (err, res) {
                    if (err || !res.ok) {
                        console.log('Oh no! error');
                    } else {
                        console.log('Response got ' + JSON.stringify(res.body));
                    }
                    done();
                });
        });
});


// LIKE WISE WE CAN TEST FOR OTHER CASES