// FOLLOW BELOW STEPS TO EXECUTE THIS FILE
/*
INSTALL THE DEPENDENCIES
npm install --save-dev supertest mocha chai

RUN TEST FILE
mocha todo.routes.test.js


*/
var request = require('supertest');
var app = require('../app');
// bdd approach
var assert = require('chai').assert;

// TESTING api/todos API WITH supertest and JWT TOKEN
describe('GET /todos', function () {
    it('respond with json containing a list of all todos',
        function (done) {
            request(app)
                .get('/api/todos/')
                .set('Accept', 'application/json')
                .set('Authorization', 'JWT eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJfaWQiOiI1ZWEzMWQxNTU4MWRmYzJhYzA2YWMwYTciLCJuYW1lIjoiTmFyZW5kcmEiLCJlbWFpbCI6Im5hcmVuZEBnbWFpbC5jb20iLCJ1c2VybmFtZSI6Im5hcmVuZCIsInBhc3N3b3JkIjoiJDJhJDEwJGRXYjVJWDhpZG1QMnVGd0E4cWoyYS5oVjVzaGp2eTdFblRyRzZkR2dGcHpYRGVBdEhZLnlXIiwiX192IjowLCJpYXQiOjE1ODc3NDg5ODEsImV4cCI6MTU4ODM1Mzc4MX0.OBsYrKlz_SCJpoqFammFWh_WRyVEf6JlLppa6vlvgm4')
                .expect('Content-Type', /json/)
                .expect(200)
                .end(function (err, res) {
                    console.log(res.body);
                    var expectedTodos = [
                        {
                            "_id": "5ea2eef29bfaaf27dc0b8399",
                            "todoDescription": "Developing API",
                            "todoResponsible": "Narendra",
                            "todoStatus": "Completed",
                            "__v": 0
                        },
                        {
                            "_id": "5ea2ef119bfaaf27dc0b839a",
                            "todoDescription": "Testing API",
                            "todoResponsible": "Sonu",
                            "todoStatus": "Completed",
                            "__v": 0
                        }
                    ];
                    assert.deepEqual(res.body, expectedTodos);
                    done();
                });
        });
});


// LIKE WISE WE CAN TEST FOR OTHER CASES