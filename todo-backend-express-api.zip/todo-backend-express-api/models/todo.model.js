// IMPORT mongoose module
const mongoose = require('mongoose');
// create object of mongoose.Schema
const Schema = mongoose.Schema;

// Define Schema
let TodoSchema = new Schema({
    todoDescription: {
        type: String
    },
    todoResponsible: {
        type: String
    },
    todoStatus: {
        type: String
    }
}, {
        collection: 'todos'
    });

module.exports = mongoose.model('Todo', TodoSchema);