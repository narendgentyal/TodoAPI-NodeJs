// STEP1: IMPORT MONGOOSE MODULE
const mongoose = require('mongoose');
// for encryption of password
const bcrypt = require('bcryptjs');
// STEP2: CREATE SCHEMA OBJECT
const Schema = mongoose.Schema;

// STEP3: CREATE OUR SCHEMA WITH OPTIONALLY ADDING VALIDATIONS
// SIMPLE SCHEMA
// const UserSchema = mongoose.Schema({
const UserSchema = new Schema({
    name: { type: String },
    email: { type: String, required: true },
    username: { type: String, required: true },
    password: { type: String, required: true },
});

// STEP4: EXPORT SCHEMA
const User = module.exports =
    mongoose.model('User', UserSchema);

// User.addUser() function exported from here
module.exports.addUser = function (newUser, callback) {
    // encryption logic
    bcrypt.genSalt(10, (err, salt) => {
        bcrypt.hash(newUser.password, salt,
            (err, hash) => {
                if (err) throw err;

                newUser.password = hash;
                newUser.save(callback);
            })
    })
} //end of addUser() function

// User.getUsersByUserName() function exported from here
module.exports.getUsersByUserName =
    function (email, callback) {
        const query = { email: email };
        User.findOne(query, callback);
    } //end of getUsersByUserName() function

// User.comparePassword() function exported from here
module.exports.comparePassword
    = function (candidatePassword, hash, callback) {
        bcrypt.compare(candidatePassword, hash,
            (err, isMatch) => {
                if (err) throw err;
                callback(null, isMatch);
            })
    } //end of comparePassword() function

// User.getUsersById()
module.exports.getUsersById = function (id, callback) {
    User.findById(id, callback);
}



